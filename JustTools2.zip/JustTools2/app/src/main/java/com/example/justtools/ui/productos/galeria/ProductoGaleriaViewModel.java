package com.example.justtools.ui.productos.galeria;

import androidx.lifecycle.ViewModel;

public class ProductoGaleriaViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}