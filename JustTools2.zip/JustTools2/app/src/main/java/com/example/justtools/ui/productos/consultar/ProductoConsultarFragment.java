package com.example.justtools.ui.productos.consultar;

import androidx.lifecycle.ViewModelProvider;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;
import android.widget.SimpleAdapter;

import com.example.justtools.R;
import com.example.justtools.databinding.ProductoConsultarFragmentBinding;

import java.util.ArrayList;
import java.util.HashMap;

public class ProductoConsultarFragment extends Fragment {

    private ProductoConsultarViewModel mViewModel;
    private ProductoConsultarFragmentBinding binding;

    private ListView lvProductos;
    private String[] from = new String[] { "Categoria", "Nombre", "Stock" };
    private int[] to = new int[] { R.id.sku, R.id.nombre, R.id.stock };

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {

        //return  inflater.inflate(R.layout.producto_consultar_fragment, container, false);;

        binding = ProductoConsultarFragmentBinding.inflate(inflater, container, false);
        View root = binding.getRoot();

        //Asignando valores a contenedor listView
        lvProductos = (ListView) root.findViewById(R.id.lv_productos);
        SimpleAdapter adapter = new SimpleAdapter(getActivity(), this.prepararData(), R.layout.listview_item_productos, from, to);
        lvProductos.setAdapter(adapter);
        //Fin

        return root;
    }

    ArrayList prepararData(){


        ArrayList<String[]> lista = new ArrayList<String[]>();

        String[] evento1 = { "SKU: 51662", "Cinta de doble contacto 19mm x 5 metros", "Stock: 50 unidades", "1" };
        String[] evento2 = { "SKU: 134532", "Plastico protector 4mx5m", "Stock: 90 unidades", "2" };
        String[] evento3 = { "SKU: 118383", "Base metálica para electrodomesticos HBM-60LR", "Stock: 25 unidades", "3" };

        lista.add(evento1);
        lista.add(evento2);
        lista.add(evento3);

        ArrayList<HashMap<String, String>> eventos = new ArrayList<HashMap<String, String>>();

        for (String[] evento : lista) {
            HashMap<String, String> datosEvento = new HashMap<String, String>();

            datosEvento.put("Categoria", evento[0]);
            datosEvento.put("Nombre", evento[1]);
            datosEvento.put("Stock", evento[2]);
            datosEvento.put("id", evento[3]);

            eventos.add(datosEvento);
        }
        return eventos;
    }
    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        mViewModel = new ViewModelProvider(this).get(ProductoConsultarViewModel.class);
        // TODO: Use the ViewModel
    }

}