package com.example.justtools.ui.productos.galeria;

import androidx.lifecycle.ViewModelProvider;

import android.content.Intent;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.GridView;

import com.example.justtools.databinding.ProductoConsultarFragmentBinding;
import com.example.justtools.databinding.ProductoGaleriaFragmentBinding;
import com.example.justtools.R;

public class ProductoGaleriaFragment extends Fragment {

    private ProductoGaleriaViewModel mViewModel;
    private ProductoGaleriaFragmentBinding binding;
    GridView gridView;

    public static ProductoGaleriaFragment newInstance() {
        return new ProductoGaleriaFragment();
    }

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {

        binding = ProductoGaleriaFragmentBinding.inflate(inflater, container, false);
        View root = binding.getRoot();
        gridView = (GridView)  root.findViewById(R.id.gv_imagenes);
        gridView.setAdapter(new GaleriaFotosAdapter(getActivity()));
        gridView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
               // Intent intent = new Intent(getAp)
            }
        });

        return root;
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        mViewModel = new ViewModelProvider(this).get(ProductoGaleriaViewModel.class);
        // TODO: Use the ViewModel
    }

}