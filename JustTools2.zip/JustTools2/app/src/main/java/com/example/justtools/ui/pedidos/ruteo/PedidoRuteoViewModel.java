package com.example.justtools.ui.pedidos.ruteo;

import androidx.lifecycle.ViewModel;

public class PedidoRuteoViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}