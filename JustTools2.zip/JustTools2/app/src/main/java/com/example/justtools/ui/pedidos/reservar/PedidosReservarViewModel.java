package com.example.justtools.ui.pedidos.reservar;

import androidx.lifecycle.ViewModel;

public class PedidosReservarViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}