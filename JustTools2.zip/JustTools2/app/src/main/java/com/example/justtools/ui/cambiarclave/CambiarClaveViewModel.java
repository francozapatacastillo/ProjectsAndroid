package com.example.justtools.ui.cambiarclave;

import androidx.lifecycle.ViewModel;

public class CambiarClaveViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}