package com.example.justtools.ui.pedidos.ruteo;

import androidx.fragment.app.FragmentManager;
import androidx.lifecycle.ViewModelProvider;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.example.justtools.R;
import com.example.justtools.databinding.PedidosRuteoFragmentBinding;

import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;


public class PedidoRuteoFragment extends Fragment implements OnMapReadyCallback {

    private PedidoRuteoViewModel mViewModel;
    private PedidosRuteoFragmentBinding binding;
    public static PedidoRuteoFragment newInstance() {
        return new PedidoRuteoFragment();
    }

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {

        binding = PedidosRuteoFragmentBinding.inflate(inflater, container, false);
        View root = binding.getRoot();

        //SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
        //        .findFragmentById(R.id.mapView);
        //mapFragment.getMapAsync(this);

        return root;
    }


    @Override
    public void onMapReady(GoogleMap googleMap) {
        googleMap.addMarker(new MarkerOptions()
                .position(new LatLng(0, 0))
                .title("Marker"));
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        mViewModel = new ViewModelProvider(this).get(PedidoRuteoViewModel.class);
        // TODO: Use the ViewModel
    }

}