package com.example.justtools.ui.productos.galeria;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.GridView;
import android.widget.ImageView;

import com.example.justtools.R;

public class GaleriaFotosAdapter  extends BaseAdapter {
    private Context mContext;
    public int[]  imageArray ={
            R.drawable.producto1,
            R.drawable.producto2,
            R.drawable.producto3,
            R.drawable.producto4,
            R.drawable.producto5,
            R.drawable.producto6,
            R.drawable.producto7,
            R.drawable.producto8,
            R.drawable.producto9,
            R.drawable.producto10,
            R.drawable.producto11,
            R.drawable.producto12,
            R.drawable.producto13,
            R.drawable.producto14,
            R.drawable.producto15,
            R.drawable.producto16,

    };

    public GaleriaFotosAdapter(Context mContext) {
        this.mContext = mContext;
    }

    @Override
    public int getCount() {
        return imageArray.length;
    }

    @Override
    public Object getItem(int i) {
        return imageArray[i];
    }

    @Override
    public long getItemId(int i) {
        return 0;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        ImageView imageView = new ImageView(mContext);
        imageView.setImageResource(imageArray[i]);
        imageView.setScaleType(ImageView.ScaleType.CENTER_CROP);
        imageView.setLayoutParams(new ViewGroup.LayoutParams(340,350));

        return imageView;
    }
}
