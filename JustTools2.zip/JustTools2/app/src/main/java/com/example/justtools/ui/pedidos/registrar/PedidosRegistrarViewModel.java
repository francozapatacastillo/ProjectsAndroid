package com.example.justtools.ui.pedidos.registrar;

import androidx.lifecycle.ViewModel;

public class PedidosRegistrarViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}