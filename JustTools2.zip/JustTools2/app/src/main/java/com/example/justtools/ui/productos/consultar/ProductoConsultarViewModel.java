package com.example.justtools.ui.productos.consultar;

import androidx.lifecycle.ViewModel;

public class ProductoConsultarViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}