package com.example.justtools.ui.pedidos.consultar;

import androidx.lifecycle.ViewModel;

public class PedidosConsultarViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}